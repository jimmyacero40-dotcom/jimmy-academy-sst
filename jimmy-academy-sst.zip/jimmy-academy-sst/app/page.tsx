'use client'

import { motion, useInView, useAnimation } from 'framer-motion'
import { useEffect, useRef, useState } from 'react'
import {
  Shield, BookOpen, PenTool, Award, BarChart2,
  Brain, Lock, ArrowRight, Play, Check,
  ChevronRight, Zap, Users, FileCheck, TrendingUp
} from 'lucide-react'

/* ────────────────────────────
   ANIMATED COUNTER HOOK
──────────────────────────── */
function useCounter(end: number, duration = 2000, suffix = '') {
  const [count, setCount] = useState(0)
  const ref = useRef<HTMLDivElement>(null)
  const inView = useInView(ref, { once: true, margin: '-80px' })

  useEffect(() => {
    if (!inView) return
    let startTime: number
    const step = (timestamp: number) => {
      if (!startTime) startTime = timestamp
      const progress = Math.min((timestamp - startTime) / duration, 1)
      const ease = 1 - Math.pow(1 - progress, 3) // cubic ease-out
      setCount(Math.floor(ease * end))
      if (progress < 1) requestAnimationFrame(step)
    }
    requestAnimationFrame(step)
  }, [inView, end, duration])

  return { count, ref }
}

/* ────────────────────────────
   FLOATING ORBS
──────────────────────────── */
function HeroBg() {
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none" aria-hidden>
      {/* Grid */}
      <div className="absolute inset-0 opacity-30"
        style={{
          backgroundImage: 'linear-gradient(rgba(255,255,255,.03) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,.03) 1px, transparent 1px)',
          backgroundSize: '60px 60px'
        }}
      />
      {/* Orbs */}
      <motion.div
        className="absolute rounded-full"
        style={{ width: 600, height: 600, top: -150, right: -100, filter: 'blur(90px)', background: 'radial-gradient(circle, rgba(27,79,216,0.3), transparent 70%)' }}
        animate={{ y: [0, -40, 0], scale: [1, 1.05, 1] }}
        transition={{ duration: 9, repeat: Infinity, ease: 'easeInOut' }}
      />
      <motion.div
        className="absolute rounded-full"
        style={{ width: 450, height: 450, bottom: -80, left: -100, filter: 'blur(80px)', background: 'radial-gradient(circle, rgba(16,185,129,0.25), transparent 70%)' }}
        animate={{ y: [0, 35, 0], scale: [1, 1.04, 1] }}
        transition={{ duration: 11, repeat: Infinity, ease: 'easeInOut', delay: 2 }}
      />
      <motion.div
        className="absolute rounded-full"
        style={{ width: 350, height: 350, top: '40%', right: '15%', filter: 'blur(70px)', background: 'radial-gradient(circle, rgba(124,58,237,0.2), transparent 70%)' }}
        animate={{ y: [0, -25, 0] }}
        transition={{ duration: 8, repeat: Infinity, ease: 'easeInOut', delay: 4 }}
      />
    </div>
  )
}

/* ────────────────────────────
   NAV
──────────────────────────── */
function Navbar() {
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    const fn = () => setScrolled(window.scrollY > 20)
    window.addEventListener('scroll', fn, { passive: true })
    return () => window.removeEventListener('scroll', fn)
  }, [])

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 px-6 py-4 flex items-center justify-between transition-all duration-300 ${
      scrolled ? 'bg-[rgba(10,15,30,0.85)] backdrop-blur-xl border-b border-white/8' : 'bg-transparent'
    }`}>
      <a href="/" className="flex items-center gap-2.5 font-extrabold text-[1.1rem] text-white no-underline">
        <Shield size={26} className="text-blue-400" strokeWidth={2.5} />
        <span>Jimmy Academy <span className="text-emerald-400">SST</span></span>
      </a>

      <div className="hidden md:flex items-center gap-8">
        {['Funciones', 'Dashboard', 'Precios', 'Contacto'].map(item => (
          <a key={item} href={`#${item.toLowerCase()}`}
            className="text-slate-400 hover:text-white text-sm font-medium transition-colors no-underline">
            {item}
          </a>
        ))}
      </div>

      <a href="/register"
        className="bg-gradient-to-r from-blue-600 to-blue-500 text-white px-5 py-2.5 rounded-lg text-sm font-semibold transition-all hover:-translate-y-0.5 hover:shadow-[0_0_30px_rgba(37,99,235,0.5)] no-underline">
        Comenzar Gratis →
      </a>
    </nav>
  )
}

/* ────────────────────────────
   STATS ITEM
──────────────────────────── */
function StatItem({ end, suffix, label, prefix = '' }: { end: number; suffix?: string; label: string; prefix?: string }) {
  const { count, ref } = useCounter(end)
  return (
    <div ref={ref} className="text-center">
      <div className="text-4xl font-black bg-gradient-to-r from-blue-400 to-emerald-400 bg-clip-text text-transparent">
        {prefix}{end > 999 ? count.toLocaleString('es-CO') : count}{suffix}
      </div>
      <div className="text-slate-400 text-sm mt-1.5 font-medium">{label}</div>
    </div>
  )
}

/* ────────────────────────────
   FEATURES DATA
──────────────────────────── */
const features = [
  {
    icon: BookOpen,
    color: 'from-blue-600/20 to-blue-500/10 border-blue-500/20',
    iconColor: 'text-blue-400',
    title: 'Capacitaciones Digitales',
    desc: 'Cursos interactivos con seguimiento en tiempo real. Módulos multimedia, evaluaciones automáticas y progreso individualizado.',
  },
  {
    icon: PenTool,
    color: 'from-emerald-600/20 to-emerald-500/10 border-emerald-500/20',
    iconColor: 'text-emerald-400',
    title: 'Firma Electrónica Legal',
    desc: 'Firmas digitales con plena validez jurídica bajo ley colombiana. Documentos certificados e inmutables.',
  },
  {
    icon: Award,
    color: 'from-violet-600/20 to-violet-500/10 border-violet-500/20',
    iconColor: 'text-violet-400',
    title: 'Certificados Automáticos',
    desc: 'Generación instantánea de certificados PDF con código QR de verificación y envío automático por correo.',
  },
  {
    icon: BarChart2,
    color: 'from-orange-600/20 to-orange-500/10 border-orange-500/20',
    iconColor: 'text-orange-400',
    title: 'Reportes y Auditoría',
    desc: 'Dashboards en tiempo real con métricas SST. Exportación a PDF/Excel y reportes listos para inspecciones.',
  },
  {
    icon: Brain,
    color: 'from-cyan-600/20 to-cyan-500/10 border-cyan-500/20',
    iconColor: 'text-cyan-400',
    title: 'Inteligencia Artificial',
    desc: 'IA que genera quizzes personalizados, detecta incumplimientos y predice riesgos laborales preventivamente.',
  },
  {
    icon: Lock,
    color: 'from-rose-600/20 to-rose-500/10 border-rose-500/20',
    iconColor: 'text-rose-400',
    title: 'Seguridad Enterprise',
    desc: 'Cifrado AES-256, autenticación multifactor, backups automáticos y cumplimiento con Ley 1581.',
  },
]

/* ────────────────────────────
   FEATURE CARD
──────────────────────────── */
function FeatureCard({ feature, index }: { feature: typeof features[0]; index: number }) {
  const ref = useRef(null)
  const inView = useInView(ref, { once: true, margin: '-60px' })
  const Icon = feature.icon

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 30 }}
      animate={inView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      className="group relative bg-white/4 border border-white/8 rounded-2xl p-7 cursor-default overflow-hidden transition-all duration-300 hover:-translate-y-1 hover:border-white/14"
      style={{ boxShadow: '0 4px 24px rgba(0,0,0,0.2)' }}
    >
      <div className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"
        style={{ background: 'linear-gradient(135deg, rgba(27,79,216,0.06), rgba(16,185,129,0.03))' }} />

      <div className={`w-13 h-13 rounded-xl flex items-center justify-center mb-5 bg-gradient-to-br ${feature.color} border`}>
        <Icon size={22} className={feature.iconColor} strokeWidth={2} />
      </div>

      <h3 className="text-white font-bold text-[1.05rem] mb-2.5">{feature.title}</h3>
      <p className="text-slate-400 text-sm leading-7">{feature.desc}</p>

      <div className="flex items-center gap-1.5 text-emerald-400 text-xs font-semibold mt-4 opacity-0 group-hover:opacity-100 -translate-x-2 group-hover:translate-x-0 transition-all duration-300">
        Saber más <ArrowRight size={13} />
      </div>
    </motion.div>
  )
}

/* ────────────────────────────
   DASHBOARD MOCKUP
──────────────────────────── */
function DashboardMockup() {
  const navItems = [
    { icon: BarChart2, label: 'Dashboard', active: true },
    { icon: Users, label: 'Usuarios' },
    { icon: BookOpen, label: 'Capacitaciones' },
    { icon: PenTool, label: 'Firmas' },
    { icon: Award, label: 'Certificados' },
    { icon: TrendingUp, label: 'Reportes' },
    { icon: Brain, label: 'IA SST' },
  ]

  const activity = [
    { msg: 'Carlos Mendoza completó Trabajo en Alturas', badge: 'Aprobado', color: 'text-emerald-400 bg-emerald-400/10' },
    { msg: 'María López firmó Política SST 2025', badge: 'Firmado', color: 'text-blue-400 bg-blue-400/10' },
    { msg: 'Reporte mensual generado · Diciembre', badge: 'PDF', color: 'text-orange-400 bg-orange-400/10' },
    { msg: 'Pedro García obtuvo certificado COPASST', badge: 'Emitido', color: 'text-violet-400 bg-violet-400/10' },
  ]

  return (
    <div className="bg-[#0D1629] border border-white/8 rounded-2xl overflow-hidden"
      style={{ boxShadow: '0 40px 100px rgba(0,0,0,0.6)' }}>
      {/* Window bar */}
      <div className="bg-[#111827] border-b border-white/8 px-5 py-3 flex items-center gap-2">
        <div className="w-3 h-3 rounded-full bg-[#FF5F57]" />
        <div className="w-3 h-3 rounded-full bg-[#FEBC2E]" />
        <div className="w-3 h-3 rounded-full bg-[#28C840]" />
        <span className="text-xs text-slate-500 ml-3">dashboard.jimmy-academy.co</span>
        <div className="ml-auto flex items-center gap-1.5 text-xs text-emerald-400">
          <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
          En línea
        </div>
      </div>

      <div className="flex" style={{ height: 380 }}>
        {/* Sidebar */}
        <div className="w-52 border-r border-white/8 p-3 flex flex-col gap-0.5 flex-shrink-0 hidden md:flex">
          <div className="text-xs text-slate-500 px-2 py-1.5 font-semibold uppercase tracking-wider mb-1">Menú</div>
          {navItems.map(({ icon: Icon, label, active }) => (
            <div key={label}
              className={`flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-xs font-medium cursor-default transition-all ${
                active
                  ? 'bg-blue-600/20 text-blue-400 border border-blue-500/25'
                  : 'text-slate-400 hover:bg-white/4 hover:text-white'
              }`}>
              <Icon size={14} strokeWidth={2} />
              {label}
            </div>
          ))}
        </div>

        {/* Main content */}
        <div className="flex-1 p-5 overflow-hidden">
          <div className="text-sm font-bold text-white mb-3">Resumen General</div>

          {/* Stats */}
          <div className="grid grid-cols-3 gap-2.5 mb-4">
            {[
              { val: '1,248', label: 'Empleados', color: 'text-blue-400' },
              { val: '94.2%', label: 'Cumplimiento SST', color: 'text-emerald-400' },
              { val: '37', label: 'Certif. hoy', color: 'text-violet-400' },
            ].map(({ val, label, color }) => (
              <div key={label} className="bg-white/4 border border-white/8 rounded-xl p-3">
                <div className={`text-xl font-black ${color}`}>{val}</div>
                <div className="text-xs text-slate-400 mt-0.5">{label}</div>
              </div>
            ))}
          </div>

          {/* Activity */}
          <div className="bg-white/4 border border-white/8 rounded-xl overflow-hidden">
            <div className="flex items-center justify-between px-4 py-2.5 bg-white/2 border-b border-white/8">
              <span className="text-xs font-bold text-slate-300">Actividad Reciente</span>
              <span className="text-[10px] text-emerald-400 font-semibold flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 inline-block animate-pulse" />
                En vivo
              </span>
            </div>
            {activity.map(({ msg, badge, color }, i) => (
              <div key={i} className="flex items-center gap-3 px-4 py-2.5 border-b border-white/4 last:border-0">
                <span className="flex-1 text-xs text-white/80">{msg}</span>
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${color}`}>{badge}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

/* ────────────────────────────
   MAIN PAGE
──────────────────────────── */
export default function HomePage() {
  return (
    <div className="dark min-h-screen bg-[#0A0F1E] text-white">
      <Navbar />

      {/* ── HERO ── */}
      <section className="relative min-h-screen flex items-center justify-center px-6 pt-28 pb-16 overflow-hidden">
        <HeroBg />

        <div className="relative z-10 text-center max-w-4xl mx-auto">
          {/* Badge */}
          <motion.div
            initial={{ opacity: 0, y: -16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="inline-flex items-center gap-2 bg-emerald-400/10 border border-emerald-400/25 text-emerald-300 px-4 py-1.5 rounded-full text-xs font-semibold mb-8"
          >
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            🇨🇴 Plataforma #1 en Colombia para SG-SST
          </motion.div>

          {/* Title */}
          <motion.h1
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.1 }}
            className="text-5xl md:text-7xl font-black leading-[1.08] tracking-tight mb-6"
          >
            Gestión SST<br />
            <span className="bg-gradient-to-r from-blue-400 via-emerald-400 to-violet-400 bg-clip-text text-transparent">
              Inteligente
            </span>
          </motion.h1>

          {/* Subtitle */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.2 }}
            className="text-lg md:text-xl text-slate-400 max-w-xl mx-auto mb-10 leading-relaxed"
          >
            Capacitaciones digitales, firma electrónica con validez legal y
            certificados automáticos con IA. Todo en una sola plataforma.
          </motion.p>

          {/* CTA Buttons */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.3 }}
            className="flex flex-wrap gap-4 justify-center"
          >
            <a href="/register"
              className="bg-gradient-to-r from-blue-700 to-blue-500 text-white px-8 py-4 rounded-xl font-bold text-base transition-all hover:-translate-y-1 no-underline flex items-center gap-2"
              style={{ boxShadow: '0 0 40px rgba(37,99,235,0.4)' }}>
              Comenzar Gratis <ArrowRight size={18} />
            </a>
            <a href="#preview"
              className="bg-white/5 border border-white/12 text-white px-8 py-4 rounded-xl font-semibold text-base transition-all hover:bg-white/10 no-underline flex items-center gap-2">
              <Play size={16} className="fill-current" /> Ver Demo
            </a>
          </motion.div>

          {/* Trust badges */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.7, delay: 0.5 }}
            className="flex flex-wrap gap-6 justify-center mt-10 text-slate-500 text-xs"
          >
            {['✓ Sin tarjeta de crédito', '✓ 30 días gratis', '✓ Configuración en 10 min'].map(t => (
              <span key={t} className="flex items-center gap-1.5">{t}</span>
            ))}
          </motion.div>
        </div>
      </section>

      {/* ── STATS ── */}
      <div className="py-12 bg-white/2 border-y border-white/8">
        <div className="max-w-5xl mx-auto px-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <StatItem end={10000} suffix="+" label="Empleados Capacitados" />
            <StatItem end={500} suffix="+" label="Empresas Certificadas" />
            <StatItem end={99} suffix="%" label="Uptime Garantizado" />
            <StatItem end={45000} suffix="+" label="Certificados Emitidos" />
          </div>
        </div>
      </div>

      {/* ── FEATURES ── */}
      <section id="funciones" className="py-28 px-6 bg-[#0D1629]">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <div className="text-emerald-400 text-xs font-bold tracking-widest uppercase mb-3">Funcionalidades Clave</div>
            <h2 className="text-4xl md:text-5xl font-black tracking-tight mb-4">
              Todo para cumplir con el{' '}
              <span className="bg-gradient-to-r from-blue-400 to-emerald-400 bg-clip-text text-transparent">SG-SST</span>
            </h2>
            <p className="text-slate-400 text-lg max-w-xl mx-auto">
              Plataforma integral diseñada para empresas colombianas que necesitan cumplir con la normatividad SST.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
            {features.map((f, i) => <FeatureCard key={f.title} feature={f} index={i} />)}
          </div>
        </div>
      </section>

      {/* ── DASHBOARD PREVIEW ── */}
      <section id="preview" className="py-28 px-6 bg-[#0A0F1E]">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-14">
            <div className="text-blue-400 text-xs font-bold tracking-widest uppercase mb-3">Vista Previa</div>
            <h2 className="text-4xl md:text-5xl font-black tracking-tight mb-4">
              Panel de control{' '}
              <span className="bg-gradient-to-r from-blue-400 to-violet-400 bg-clip-text text-transparent">
                intuitivo
              </span>
            </h2>
            <p className="text-slate-400 text-lg max-w-xl mx-auto">
              Toda la información SST de tu empresa en un solo lugar, accesible desde cualquier dispositivo.
            </p>
          </div>

          <motion.div
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-80px' }}
            transition={{ duration: 0.7 }}
          >
            <DashboardMockup />
          </motion.div>
        </div>
      </section>

      {/* ── CTA ── */}
      <section id="precios" className="py-28 px-6 relative overflow-hidden"
        style={{ background: 'linear-gradient(135deg, #0D1F4A 0%, #0A1628 50%, #0D2040 100%)' }}>
        <div className="absolute inset-0 pointer-events-none"
          style={{ background: 'radial-gradient(ellipse 80% 60% at 50% 50%, rgba(27,79,216,0.2), transparent 70%)' }} />

        <div className="relative z-10 max-w-2xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <div className="inline-flex items-center gap-2 bg-white/6 border border-white/12 text-slate-300 px-4 py-1.5 rounded-full text-xs font-semibold mb-8">
              ✨ Sin tarjeta de crédito requerida
            </div>

            <h2 className="text-5xl md:text-6xl font-black tracking-tight mb-5">
              Empieza hoy.<br />
              <span className="bg-gradient-to-r from-blue-400 to-emerald-400 bg-clip-text text-transparent">
                30 días gratis
              </span>
            </h2>

            <p className="text-slate-400 text-lg mb-10">
              Únete a más de 500 empresas que ya gestionan su SG-SST con Jimmy Academy.
              Configuración en menos de 10 minutos.
            </p>

            <div className="flex flex-wrap gap-4 justify-center">
              <a href="/register"
                className="bg-gradient-to-r from-blue-700 to-blue-500 text-white px-10 py-4 rounded-xl font-bold text-lg transition-all hover:-translate-y-1 no-underline flex items-center gap-2"
                style={{ boxShadow: '0 0 50px rgba(37,99,235,0.45)' }}>
                Crear cuenta gratis <ArrowRight size={20} />
              </a>
              <a href="/contacto"
                className="bg-white/6 border border-white/12 text-white px-10 py-4 rounded-xl font-semibold text-lg transition-all hover:bg-white/12 no-underline">
                Hablar con un experto
              </a>
            </div>

            <div className="grid grid-cols-3 gap-6 mt-14 pt-10 border-t border-white/8">
              {[
                { icon: Zap, label: 'Setup rápido', sub: 'En menos de 10 min' },
                { icon: Shield, label: 'Seguridad garantizada', sub: 'Cifrado AES-256' },
                { icon: FileCheck, label: 'Legalmente válido', sub: 'Ley colombiana' },
              ].map(({ icon: Icon, label, sub }) => (
                <div key={label} className="text-center">
                  <div className="w-10 h-10 rounded-xl bg-white/6 border border-white/12 flex items-center justify-center mx-auto mb-2">
                    <Icon size={18} className="text-blue-400" />
                  </div>
                  <div className="text-sm font-semibold text-white">{label}</div>
                  <div className="text-xs text-slate-500 mt-0.5">{sub}</div>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* ── FOOTER ── */}
      <footer className="bg-[#111827] border-t border-white/6 py-10 px-6 text-center">
        <div className="flex items-center justify-center gap-2.5 font-extrabold text-white mb-4">
          <Shield size={20} className="text-blue-400" />
          <span>Jimmy Academy <span className="text-emerald-400">SST</span></span>
        </div>
        <div className="flex flex-wrap gap-x-6 gap-y-2 justify-center mb-5">
          {['Privacidad', 'Términos', 'Soporte', 'Blog', 'Documentación'].map(link => (
            <a key={link} href="#" className="text-slate-500 hover:text-slate-300 text-sm no-underline transition-colors">{link}</a>
          ))}
        </div>
        <p className="text-slate-600 text-sm">
          © {new Date().getFullYear()} Jimmy Academy SST · Medellín, Colombia · Todos los derechos reservados
        </p>
      </footer>
    </div>
  )
}
